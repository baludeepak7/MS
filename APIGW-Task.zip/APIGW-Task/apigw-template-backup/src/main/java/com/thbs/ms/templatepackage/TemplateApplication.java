package com.thbs.ms.banking;

import org.openapitools.jackson.nullable.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class #APP_NAME#Application {

	public static void main(String[] args) {
		SpringApplication.run(#APP_NAME#Application.class, args);
	}

}
